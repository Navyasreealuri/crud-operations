const config = {
    host: "localhost",
    user: "Navya Sree",
    password: "sweeTy@03",
    database: "test"
  };
  
  module.exports = config;
  